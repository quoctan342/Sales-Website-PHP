<?php
require("header.php");
require("mainmenu.php");
require("footer.php");
?>